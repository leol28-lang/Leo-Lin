// 棍木塔防 · 网页联机版服务器（无依赖，Node 18+ 内置 http）
// 房主的浏览器运行模拟（金币共用、AI 队友也在房主端行动）；
// 服务器负责：静态页面、房间、座位、转发其他玩家的操作、转发房主的快照、转发聊天和建造光标。
//
// 环境变量（都有默认值）：
//   PORT            监听端口，默认 3000（云平台会自动注入）
//   HOST            监听地址，默认 0.0.0.0
//   TRUST_PROXY     部署在反向代理（Render / Nginx 等）后面时设为 1，用于识别真实 IP
//   MAX_ROOMS       同时存在的房间上限，默认 300
//   RATE_MAX        每个 IP 每 10 秒最多的接口调用次数，默认 150
//   CREATE_PER_10MIN 每个 IP 每 10 分钟最多创建房间次数，默认 20
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const HTML_PATH = path.join(__dirname, 'public', 'index.html');
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const MAX_ROOMS = Number(process.env.MAX_ROOMS) || 300;
const MAX_BODY = 1.5e6;                                       // 单次请求体上限（快照可能较大）
const RATE = { windowMs: 10000, max: Number(process.env.RATE_MAX) || 150 };
const CREATE_LIMIT = { windowMs: 600000, max: Number(process.env.CREATE_PER_10MIN) || 20 };
const startedAt = Date.now();
const TIMEOUT_MS = 12000;      // 超过这个时间没有轮询就视为离开
const HOVER_MS = 1800;         // 光标位置保留时间
const SEAT_MAX = 6;
const CODE_CH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const CHAT_MAX_LEN = 60;
const CHAT_KEEP = 150;          // 房间内保留的最近消息数
const CHAT_RATE = { n: 6, ms: 5000 };   // 每人每 5 秒最多 6 条

const rooms = new Map();

function newCode() {
  for (;;) {
    let s = '';
    for (let i = 0; i < 4; i++) s += CODE_CH[Math.floor(Math.random() * CODE_CH.length)];
    if (!rooms.has(s)) return s;
  }
}
function newPid() { return Math.random().toString(36).slice(2, 12); }

// 去掉控制字符，限制长度，空名字用默认值
function cleanName(x, fallback) {
  const s = String(x == null ? '' : x).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 12);
  return s || fallback;
}

function makeSeats() {
  const seats = [];
  for (let i = 0; i < SEAT_MAX; i++) seats.push({ ai: i > 0, closed: false, pid: null });
  return seats;
}

function makeRoom(hostName) {
  const code = newCode();
  const hostPid = newPid();
  const seats = makeSeats();
  seats[0] = { ai: false, closed: false, pid: hostPid };
  const room = {
    code, hostPid, phase: 'lobby', round: 0, map: 0, diff: 'normal',
    seatCount: 4,
    players: new Map([[hostPid, { name: hostName || '房主', last: Date.now() }]]),
    seats,
    snap: null, snapV: 0, actions: [], hovers: new Map(),
    chat: [], chatSeq: 0, rate: new Map()
  };
  rooms.set(code, room);
  return { room, pid: hostPid };
}

function seatIndexOf(room, pid) { return room.seats.findIndex(s => s.pid === pid); }

function pushChat(room, m) {
  room.chatSeq++;
  room.chat.push(Object.assign({ id: room.chatSeq, t: Date.now() }, m));
  if (room.chat.length > CHAT_KEEP) room.chat.splice(0, room.chat.length - CHAT_KEEP);
}
function sysChat(room, text) { pushChat(room, { k: 'sys', s: -1, n: '', x: text }); }

function view(room, pid) {
  return {
    code: room.code,
    phase: room.phase,
    round: room.round,
    map: room.map,
    diff: room.diff,
    host: room.hostPid === pid,
    seatCount: room.seatCount,
    seats: room.seats.slice(0, room.seatCount).map((s, i) => {
      const pl = s.pid ? room.players.get(s.pid) : null;
      return {
        i,
        state: s.pid ? 'human' : (s.closed ? 'closed' : 'ai'),
        name: pl ? pl.name : (s.closed ? '关闭' : 'AI 队友'),
        me: !!s.pid && s.pid === pid,
        host: room.hostPid === s.pid && !!s.pid
      };
    })
  };
}

function getRoom(body) {
  const room = rooms.get(String((body && body.code) || '').toUpperCase());
  if (!room) throw new Error('房间不存在或已关闭');
  const pl = room.players.get(body.pid);
  if (!pl) throw new Error('你已不在房间中，请重新加入');
  pl.last = Date.now();
  return room;
}

function clampInt(x, lo, hi) {
  const n = Number(x);
  return Number.isInteger(n) && n >= lo && n <= hi ? n : null;
}

const handlers = {
  create(body, ctx) {
    if (rooms.size >= MAX_ROOMS) throw new Error('服务器房间已满，请稍后再试');
    if (ctx && overLimit(ipCreates, ctx.ip, CREATE_LIMIT)) throw new Error('你创建房间太频繁了，请稍后再试');
    const { room, pid } = makeRoom(cleanName(body.name, '房主'));
    return { code: room.code, pid, room: view(room, pid) };
  },
  join(body) {
    const code = String(body.code || '').toUpperCase();
    const room = rooms.get(code);
    if (!room) throw new Error('房间不存在');
    const seat = room.seats.slice(0, room.seatCount).find(s => s.ai && !s.pid && !s.closed);
    if (!seat) throw new Error('房间已满');
    const pid = newPid();
    room.players.set(pid, { name: cleanName(body.name, '玩家'), last: Date.now() });
    seat.ai = false; seat.pid = pid;
    sysChat(room, `${room.players.get(pid).name} 加入了房间`);
    return { code, pid, room: view(room, pid) };
  },
  leave(body) {
    const room = rooms.get(String(body.code || '').toUpperCase());
    if (room) removePlayer(room, body.pid);
    return {};
  },
  // 每 250ms 一次。房主额外上传快照；每个人都上报自己的建造光标
  poll(body) {
    const room = getRoom(body);
    const now = Date.now();
    if (body.hover && typeof body.hover === 'object') {
      const r = clampInt(body.hover.r, 0, 30), c = clampInt(body.hover.c, 0, 30);
      if (r !== null && c !== null) {
        const ty = String(body.hover.ty || '').replace(/[^A-Za-z0-9_]/g, '').slice(0, 20);
        room.hovers.set(body.pid, { r, c, ty, t: now });
      }
    } else {
      room.hovers.delete(body.pid);
    }
    const isHost = room.hostPid === body.pid;
    if (isHost && body.snap && typeof body.snap === 'object' && room.phase === 'playing') {
      room.snap = body.snap;
      room.snapV++;
    }
    let actions = [];
    if (isHost) { actions = room.actions; room.actions = []; }
    const hovers = [];
    for (const [pid, h] of [...room.hovers]) {
      if (now - h.t > HOVER_MS || !room.players.has(pid)) { room.hovers.delete(pid); continue; }
      hovers.push({ r: h.r, c: h.c, ty: h.ty, seat: seatIndexOf(room, pid) });
    }
    const since = Number(body.since) || 0;
    const chat = room.chat.filter(m => m.id > since).slice(-50);
    return {
      chat,
      chatSeq: room.chatSeq,
      room: view(room, body.pid),
      snapV: room.snapV,
      snap: isHost ? null : room.snap,
      actions,
      hovers
    };
  },
  // 聊天：所有人都能发；快捷语音 q=true
  chat(body) {
    const room = getRoom(body);
    const text = String(body.text || '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim();
    if (!text) throw new Error('消息不能为空');
    if (text.length > CHAT_MAX_LEN) throw new Error(`消息最多 ${CHAT_MAX_LEN} 个字`);
    const now = Date.now();
    const times = (room.rate.get(body.pid) || []).filter(t => now - t < CHAT_RATE.ms);
    if (times.length >= CHAT_RATE.n) throw new Error('发得太快了，稍等一下');
    times.push(now);
    room.rate.set(body.pid, times);
    const pl = room.players.get(body.pid);
    pushChat(room, { k: body.q ? 'quick' : 'chat', s: seatIndexOf(room, body.pid), n: pl.name, x: text });
    return {};
  },
  // 非房主的操作请求，由房主端执行
  act(body) {
    const room = getRoom(body);
    if (room.phase !== 'playing') throw new Error('游戏还没开始');
    if (!body.a || typeof body.a !== 'object' || JSON.stringify(body.a).length > 2000) throw new Error('操作无效');
    if (room.actions.length < 300) room.actions.push({ from: seatIndexOf(room, body.pid), a: body.a });
    return {};
  },
  config(body) {
    const room = getRoom(body);
    if (room.hostPid !== body.pid) throw new Error('只有房主可以修改');
    if (body.seatCount !== undefined) {
      const n = clampInt(body.seatCount, 1, SEAT_MAX);
      if (n === null) throw new Error('座位数无效');
      for (let i = n; i < SEAT_MAX; i++) {
        if (room.seats[i].pid) throw new Error('请先请走该座位上的玩家');
      }
      room.seatCount = n;
    }
    if (body.seat !== undefined) {
      const i = clampInt(body.seat, 1, room.seatCount - 1);
      if (i === null) throw new Error('座位无效');
      const s = room.seats[i];
      if (s.pid) removePlayer(room, s.pid, '被房主请出了房间');   // 请走真人
      if (body.state === 'ai') { s.ai = true; s.closed = false; }
      else if (body.state === 'closed') { s.ai = false; s.closed = true; }
      else throw new Error('座位状态无效');
    }
    if (body.map !== undefined) {
      const m = clampInt(body.map, 0, 6);
      if (m === null) throw new Error('关卡无效');
      room.map = m;
    }
    if (body.diff !== undefined) {
      if (!['easy', 'normal', 'hard'].includes(body.diff)) throw new Error('难度无效');
      room.diff = body.diff;
    }
    return { room: view(room, body.pid) };
  },
  phase(body) {
    const room = getRoom(body);
    if (room.hostPid !== body.pid) throw new Error('只有房主可以开始');
    if (body.stop) {
      room.phase = 'lobby';
    } else {
      room.phase = 'playing';
      room.round++;
      sysChat(room, `房主开始了第 ${room.round} 局`);
      room.map = clampInt(body.map, 0, 6) ?? room.map;
      if (['easy', 'normal', 'hard'].includes(body.diff)) room.diff = body.diff;
      room.snap = null; room.snapV++; room.actions = [];
    }
    return { room: view(room, body.pid) };
  }
};

function removePlayer(room, pid, reason) {
  if (room.hostPid === pid) { rooms.delete(room.code); return; }
  const pl = room.players.get(pid);
  if (pl) sysChat(room, `${pl.name} ${reason || '离开了房间'}`);
  room.players.delete(pid);
  room.rate.delete(pid);
  room.hovers.delete(pid);
  for (const s of room.seats) if (s.pid === pid) { s.pid = null; s.ai = true; s.closed = false; }
}

// 清理掉线的玩家；房主掉线则整个房间关闭
setInterval(() => {
  const now = Date.now();
  for (const room of [...rooms.values()]) {
    const host = room.players.get(room.hostPid);
    if (!host || now - host.last > TIMEOUT_MS) { rooms.delete(room.code); continue; }
    for (const [pid, pl] of [...room.players]) {
      if (now - pl.last > TIMEOUT_MS) removePlayer(room, pid, '掉线了');
    }
  }
}, 3000);

function send(res, status, obj, type) {
  const body = typeof obj === 'string' ? obj : JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': type || 'application/json; charset=utf-8',
    'Cache-Control': type ? 'no-cache' : 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer'
  });
  res.end(body);
}

function clientIp(req) {
  if (TRUST_PROXY) {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xf) return xf;
  }
  return req.socket.remoteAddress || 'unknown';
}

// 滑动窗口限流：超过上限返回 true
const ipHits = new Map(), ipCreates = new Map();
function overLimit(map, key, cfg) {
  const now = Date.now();
  const arr = (map.get(key) || []).filter(t => now - t < cfg.windowMs);
  const over = arr.length >= cfg.max;
  if (!over) arr.push(now);
  map.set(key, arr);
  return over;
}
setInterval(() => {
  const now = Date.now();
  for (const map of [ipHits, ipCreates]) {
    for (const [k, arr] of [...map]) {
      const live = arr.filter(t => now - t < CREATE_LIMIT.windowMs);
      if (live.length) map.set(k, live); else map.delete(k);
    }
  }
}, 60000).unref();

let indexHtml = '';
try {
  indexHtml = fs.readFileSync(HTML_PATH, 'utf8');
} catch (err) {
  console.error('找不到游戏页面：' + HTML_PATH);
  process.exit(1);
}

const server = http.createServer((req, res) => {
  req.on('error', () => {});
  const url = req.url.split('?')[0];
  if (req.method === 'GET' && url === '/healthz') {
    return send(res, 200, { ok: true, rooms: rooms.size, uptime: Math.round((Date.now() - startedAt) / 1000) });
  }
  if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
    return send(res, 200, indexHtml, 'text/html; charset=utf-8');
  }
  if (req.method === 'GET' && url === '/favicon.ico') { res.writeHead(204); return res.end(); }

  const m = /^\/api\/(\w+)$/.exec(url);
  if (req.method === 'POST' && m && handlers[m[1]]) {
    const ip = clientIp(req);
    if (overLimit(ipHits, ip, RATE)) return send(res, 429, { error: '操作太频繁，请稍后再试' });
    const chunks = [];
    let size = 0, aborted = false;
    req.on('data', chunk => {
      if (aborted) return;
      size += chunk.length;
      if (size > MAX_BODY) { aborted = true; send(res, 413, { error: '请求内容太大' }); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (aborted) return;
      let body = {};
      try {
        const data = Buffer.concat(chunks).toString('utf8');
        body = data ? JSON.parse(data) : {};
      } catch (err) { return send(res, 400, { error: '请求格式错误' }); }
      if (!body || typeof body !== 'object' || Array.isArray(body)) return send(res, 400, { error: '请求格式错误' });
      try { return send(res, 200, handlers[m[1]](body, { ip })); }
      catch (err) { return send(res, 400, { error: err.message || '请求失败' }); }
    });
    return;
  }
  send(res, 404, { error: 'not found' });
});

function shutdown() {
  console.log('正在关闭服务器……');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

server.listen(PORT, HOST, () => console.log(`棍木塔防网页版已启动：http://${HOST}:${PORT}`));
